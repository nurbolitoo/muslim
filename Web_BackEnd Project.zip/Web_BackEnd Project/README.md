# Web Technologies 2 (Back End)

## Requiment for running
#### 1) create .env file
#### 2) add 3 variables into .env file:
#### -    SERVER_ACCESS - mongoDB database address
#### -    STOCK_MARKET_API - API key for website https://www.alphavantage.co/
#### -    NEWS_API - API key for website https://newsapi.org/
